import os
import time 
import csv
import hashlib

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
VAULT_PATH = os.path.join(SCRIPT_DIR, "vault.csv")

emails = []
usernamesl = []
usernames = []
passwords = []

def hash_password(password):
    hashed = hashlib.sha256(password.encode()).hexdigest()
    return hashed

try:
    with open(VAULT_PATH, "r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            emails.append(row["email"].lower())
            usernamesl.append(row["username"].lower())
            usernames.append(row["username"])
            passwords.append(row["password"])
        run = True
except FileNotFoundError:
    print(" File Not Openable")



def signUp():
    os.system('cls' if os.name == 'nt' else 'clear')
    valid = False
    pass_number = False
    pass_uppercase = False
    pass_lowercase = False
    pass_specialchar = False
    specialchars = ["#", "@" , "!", "£", "$", "%", "^", "&", "*", "(", ")", "_", "-", "+","="]
    print("\n--------------------------------------\n")
    new_email = ""
    new_username = ""
    new_password = ""

    while True:

        new_email = input("\nEnter Email  : ")
        if new_email.lower() in emails:
            print("\n Account already exists under that email\n")
        elif "@" in new_email and "." in new_email.lower() and len(new_email) >= 4 :
            print("\n Email Accepted!")
            break
        else:
            print("\n Invalid Email\n")

    while True:

        new_username = input("\nCreate Username : ")
        if new_username == "":
            print("\n Invalid Username\n")
        elif new_username.lower() in usernamesl:
            print("\n Username already exists.\n")
        else:
            print("\n Username Accepted!")
            break

    while True:
        
        new_password = input("\n\nCreate Password : ")
        if len(new_password) >= 8:
            for character in new_password:
                if character.isdigit:
                    pass_number = True
                if character.islower:
                    pass_lowercase = True
                if character.isupper:
                    pass_uppercase = True
                if character in specialchars:
                    pass_specialchar = True
        if " " in new_password:
            print("\n PASSWORD MUST CONTAIN :\n -  ATLEAST ONE CAPITAL LETTER\n -  ATLEAST ONE LOWERCASE LETTER\n -  ATLEAST ONE NUMBER\n -  ATLEAST ONE SPECIAL CHARACTER")
        elif pass_number and pass_lowercase and pass_uppercase and pass_specialchar:
            print("\n Password Accepted!")
            break
        else:
            print("\n PASSWORD MUST CONTAIN :\n -  ATLEAST ONE CAPITAL LETTER\n -  ATLEAST ONE LOWERCASE LETTER\n -  ATLEAST ONE NUMBER\n -  ATLEAST ONE SPECIAL CHARACTER")
    
    emails.append(new_email.lower())
    usernamesl.append(new_username.lower())
    usernames.append(new_username)
    hashed_pw = hash_password(new_password)
    passwords.append(hashed_pw) 
    with open(VAULT_PATH, "a", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["username", "email", "password"])
        if file.tell() == 0:
            writer.writeheader()
        writer.writerow({
            "username": new_username,
            "email": new_email,
            "password": hashed_pw
        })
    
    print("\n\nAccount Created\n")
    print("\n--------------------------------------\n\n")
    time.sleep(3)
    os.system('cls' if os.name == 'nt' else 'clear')


def signIn():
    os.system('cls' if os.name == 'nt' else 'clear')
    using_email = False
    index = 0
    correct_password = False
    password_tries = 3
    email = ""
    username = ""
    password = ""
    using = ""
    print("\n--------------------------------------\n")
    while True:
        user = input("\nEnter Username or Email: ")
        if user.lower() in username or user.lower() in email:
            break
        else:
            print("\n No user with those details!")

    while password_tries > 0:
        password = input("\nEnter Password : ")
        password_tries -= 1
        if hash_password(password) == passwords[index]:
            correct_password = True
            break
        else:
            print("\n Incorrect Password!")
            time.sleep(1)
            print(" ",password_tries, " Tries Left!")
    if correct_password == True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("\n--------------------------------------\n")
        print(" Logging in...")
        time.sleep(2)
        return True
    else:
        return False
    


while run:
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\n--------------------------------------\n")
    option = input("\n\n 1. LOGIN\n 2. SIGNUP\n\nChoice : ")
    if option == "1":
        if signIn():
            break
    elif option == "2":
        signUp()
    else:
        print("\n Unknown Input!")